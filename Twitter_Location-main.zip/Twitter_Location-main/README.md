# Twitter_Location
Extracting tweets [backend] using Python Flask.

## Package Installation for Python3:
* flask-

            pip3 install flask flask-sqlalchemy

* mysql.connector-

            pip3 install mysql-connector-python

## How to run the Flask API server?
* Run the following command on terminal/command-prompt-

            python3 main.py

* Copy the server url from prompt and run it on browser.
