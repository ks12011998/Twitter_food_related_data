#!/bin/sh
set -e

cd /app
echo "Starting Backend"
python3 main.py
