docker build -t covid-help-backend .
